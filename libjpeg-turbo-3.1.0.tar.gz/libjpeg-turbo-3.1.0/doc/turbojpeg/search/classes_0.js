var searchData=
[
  ['tjregion_0',['tjregion',['../structtjregion.html',1,'']]],
  ['tjscalingfactor_1',['tjscalingfactor',['../structtjscalingfactor.html',1,'']]],
  ['tjtransform_2',['tjtransform',['../structtjtransform.html',1,'']]]
];
